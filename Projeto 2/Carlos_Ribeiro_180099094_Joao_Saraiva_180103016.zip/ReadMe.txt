Universidade de Brasilia											    
Instituto de Ciencias Exatas										    
Departamento de Ciencia da Computação
Projeto 2
Teoria e Aplicação de Grafos, Turma A, 1/2020							    
Professor: Díbio
Aluno: Carlos Eduardo de Oliveira Ribeiro - 180099094   			
Aluno: João Gabriel Ferreira Sariava - 180103016						
Versao do compilador: g++ 9.3.0
Biblioteca Grafica utilizada: Graphviz
Caso não tenha um display instalado na maquina: sudo apt install graphicsmagick-imagemagick-compat

Descrição : Criar um digrafo utilizando os materias do fluxo do curso de ciencia da computação e executar os seguintes passos:
(1) Implementar um algoritmo de Ordenação Topológica.
(2) Gerar as três sequências mais longas (caminhos críticos).
(3) Deverão ser apresentados na tela do computador, o nome do curso, o DAG, a ordenação topologica e os caminhos críticos.
(4) Usar uma biblioteca gráfica para gerar o arquivo .png para a analise dos resultados.