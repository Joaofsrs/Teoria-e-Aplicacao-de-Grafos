#include "Trabalho.h"

using namespace std;

int main(){

    criar_grafo();
    
    emparelhamento();
    
    emparelhamento_maximo();

    return 0;
}