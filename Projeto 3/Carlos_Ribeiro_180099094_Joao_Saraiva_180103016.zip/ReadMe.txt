Universidade de Brasilia											    
Instituto de Ciencias Exatas										    
Departamento de Ciencia da Computação
Projeto 3
Teoria e Aplicação de Grafos, Turma A, 1/2020							    
Professor: Díbio
Aluno: Carlos Eduardo de Oliveira Ribeiro - 180099094   			
Aluno: João Gabriel Ferreira Sariava - 180103016						
Versao do compilador: g++ 9.3.0
Como compilar: g++ Main.cpp Trabalho.cpp -o Nomeexe

Descrição : Implementar um algoritimo que realize um emparelhamento estável seguindo os seguintes requisitos:
(1) Incluir pelo menos 1 professor por escola
(2) Tentar preencher o maximo de vagas de uma escola
(3) Mostrar quantos professores foram alocados estavelmente
