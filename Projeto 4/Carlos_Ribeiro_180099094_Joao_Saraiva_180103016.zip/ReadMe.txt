Universidade de Brasilia											    
Instituto de Ciencias Exatas										    
Departamento de Ciencia da Computação
Projeto 4
Teoria e Aplicação de Grafos, Turma A, 1/2020							    
Professor: Díbio
Aluno: Carlos Eduardo de Oliveira Ribeiro - 180099094   			
Aluno: João Gabriel Ferreira Sariava - 180103016						
Versao do compilador: g++ 9.3.0
Como Compilar: g++ Main.cpp Trabalho.cpp -o NomeDoArquivoExe
Biblioteca Grafica utilizada: Graphviz

Descrição : Implementar um algoritimo que realize uma coloração no grafo do fluxo do curso de Ciência da Computação seguindo os seguintes requisitos:
(1) Pelo menos 48 horas de uma aula para outra da mesma matéria
(2) Preencher os horários o mais proximo prossivel
(3) Gerar em uma ferramenta gráfica o grafo colorido e o grafo original
