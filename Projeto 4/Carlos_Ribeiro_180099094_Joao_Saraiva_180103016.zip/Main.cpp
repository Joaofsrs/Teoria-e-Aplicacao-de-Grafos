#include "Trabalho.h"

int main(){
    criar_grafo();
    print_materias();
    coloracao();
    criar_dot_sem_coloracao();
    mostrar_dot_sem_cor();
    criar_dot_coloracao();
    mostrar_dot_com_cor();

    return 0;
}