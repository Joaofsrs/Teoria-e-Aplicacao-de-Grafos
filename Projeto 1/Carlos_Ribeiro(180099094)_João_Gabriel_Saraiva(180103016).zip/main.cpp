#include "Trabalho.h"

using namespace std;

int main(){
    criar_grafo();
    imprime_grafo();
    BronKeborsch0();
    imprime_cliques();
    triangulos();

    return 0;
}