Universidade de Brasilia											    
Instituto de Ciencias Exatas										    
Departamento de Ciencia da Computação								    
Técnicas de Programação 2
Aluno: Carlos Eduardo de Oliveira Ribeiro - 180099094   			
Aluno: João Gabriel Ferreira Sariava - 180103016						
Versao do compilador: g++ 9.3.0
Como compilar: g++ Trabalho.cpp main.cpp -o 
                      
Descrição: Escrever um programa em C/C++ que monta um grafo não direcionado sem pesos, usando listas de adjacências, 
e então calcula e imprime como saída (tela) o seguinte:                                 
(1) O vértice, e seu respectivo grau (para todos os vértices);  
(2) Todos os cliques maximais (indicando o número de vértices e quais);
(3) O Coeficiente de Aglomeração de cada vértice;                       
(4) O Coeficiente médio de Aglomeração do Grafo.                        
